package classesEmpleat

class Adreca (var carrer: String?, var codipostal: String? ,var poblacio: String?)
