package exemples

//import net.xqj.basex.local.BaseXXQDataSource



fun main(){
	// val xqs = BaseXXQDataSource()
    //xqs.setProperty("serverName", "localhost");
    //xqs.setProperty("port", "1984");

    // Change USERNAME and PASSWORD values
    //val conn = xqs.getConnection()
}